-- CreateTable
CREATE TABLE "Notificaciones" (
    "id" SERIAL NOT NULL,
    "notificacion" TEXT NOT NULL,

    CONSTRAINT "Notificaciones_pkey" PRIMARY KEY ("id")
);
